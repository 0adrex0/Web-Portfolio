$(() => {
	
// Show , Hide mein menu 
	
	$('header .menu_Show img').click(function () {

		if ($('.menu_Content').css('display') == 'none') {
			$(this).attr("src", "img/icons/Close.png");

			$('.menu_Content').animate({
				opacity: '0.95',
				right: 0
			}, 1000).css('display', 'flex');

		} else {
			$(this).attr("src", "img/icons/Side_Menu.png");

			$('.menu_Content').animate({
				opacity: '0',
				right: '-100vh'
			}, 1000, function () {
				$('.menu_Content').css('display', 'none');
			});
		}

	});

//Sloow scroling 
	
	$('header .slide_down img').click(function () {

		$('body,html').animate({
			scrollTop: $('header').height()
		}, 1500);

	});

//Hide poster from video
	
	$('#playVideo').click(function () {
		$('.hide').animate({
			opacity: '0'
		}, 1000, function () {
			$(this).hide();
		});
	});
	let tabs = $(".portfolio_Tabs ul li");
		tabs.click(function () {
			$(tabs).removeClass('active');
			$(this).addClass('active');
			$('.greed_content .item .item_block').children().remove('.hide');
	var key = $(this).text().trim();
			
		if (key != 'All') {
			var elem = $(`.greed_content .item .item_block:not([data-category="${key}"])`).append('<div class="hide"></div>');
		}


	});

//Combo Box
	
	let comboBox = $('#comboBox');
	$('#comboBox').click(function() {
		
		if($(this).children('ul.content').css('display') == 'none'){
			$(this).children('ul.content').slideDown(800);
			$(this).children('ul.content').children().click(function(){
				$('#comboBox input').attr("placeholder",$(this).text());
				////alert();
			});
		}
		else{
		
			$(this).children('ul.content').slideUp(800);
			
		}
	});
	let formLabel = $('label.formLabel');
		formLabel.focusin(function(){
			formLabel.css( 'border-bottom', '1px solid #666');
			$(this).css( 'border-bottom', '1px solid #7443ff');
		});
		formLabel.focusout(function(){
			$(this).css( 'border-bottom', '1px solid #666');
		});
	
//Check box
	
	$('.checkbox').click(function(){
		if($(this).children().children('img').css('display') == 'none'){
			$(this).children().css('font-weight','bold');
			$(this).children().css('border-color', '#7443ff');
		}else{
			$(this).children().css('font-weight','normal');
			$(this).children().css('border-color', '#d1d1d1');
		}
		$(this).children().children('img').toggle(300);
		
	});
});
