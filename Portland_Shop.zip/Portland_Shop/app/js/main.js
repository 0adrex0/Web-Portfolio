$(() => {
	$('.menu_button img').click(function () {
		if ($('.right_menu').hasClass('active')) {
			$('.right_menu').show().animate({
				opacity: '1',
				left: '0'

			}, 1000).removeClass('active');

		} else {
			$('.right_menu').animate({
					opacity: '0',
					left: '-' + $('.right_menu').width()

				}, 1000,
				function () {
					$(this).hide().addClass('active');
				});

		}
	});

	let items = $('#slider .slider_content').children();
	let pagination = $('#slider .pagination').children();
	let cur = 0;
	let next = 0;
	$('#slider .circle').click(next_slide);

	function next_slide() {
		next++
		if (next >= items.length) next = 0;
		slide_animation();
		cur = next;
	}

	$(pagination).click(function () {

		next = $(this).index();
		slide_animation();
		cur = next;
	});

	function slide_animation() {
		$(pagination[cur]).removeClass('active');
		$(items[cur]).animate({
			left: '-100%',
			opacity: 0,
		}, 800, function () {
			$(this).removeClass('active');
			$(this).css('left', '100%');
			$(items[cur]).css('left', '100%');

			//if (current_pos >= items.length) current_pos = 0;

			$(pagination[next]).addClass('active');
			$(items[next]).addClass('active').animate({
				left: '0',
				opacity: '1'
			}, 800);

		});

	}


	let title;
	let list;
	$('.sort_comboBox span').click(function () {
		title = $(this);
		list = $(title).next('ul.list');
		if($(list).is(":visible"))
			title.css('background', `url('./img/icons/down.png') no-repeat right`);
		else
			title.css('background', `url('./img/icons/up.png') no-repeat right`);
		
		
		$(list).toggle(750);
		
		$(list).children().click(function () {
			$(title).text($(this).text());
			list.hide(750);
			
			title.css('background', `url('./img/icons/down.png') no-repeat right`);
		});

	});
	
	$('.checkbox').click(function(){
		if($(this).children().is(':visible')){
			$(this).css('background' , 'none');
			$(this).children().hide();
			return false;
		}else{
			$(this).css('background' , '#00e2aa');
			$(this).children().show();
			return true;
		}
	});
	setInterval(next_slide, 10000);
});
