var gulp = require('gulp'),
	sass = require('gulp-sass'),
	uglify = require("gulp-uglify"),
	rename = require("gulp-rename"),
	pump = require('pump'),
	cleanCSS = require('gulp-clean-css'),
	htmlmin = require('gulp-htmlmin');


gulp.task('sass', function () {
	gulp.src('app/sass/**/*.scss')
		.pipe(sass().on('error', sass.logError))
		.pipe(gulp.dest('app/css'));
});

//Watching on all elements

gulp.task('watch', function () {
	gulp.watch('app/sass/**/*.scss', ['sass']),
	gulp.watch('app/js/**/*.js', ['minJs']),
	gulp.watch('app/*.html', ['minHtml']),
	gulp.watch('app/css/**/*.css', ['minCss']);
});

//MINIFY

gulp.task('minJs', function (cb) {
  pump([
        gulp.src(['app/js/**/*.js', '!js/*.min.js']),
        uglify(),
      /*
	  	rename({suffix: '.min'}),
        gulp.dest('app/js/min')
	  */
        gulp.dest('app/minify/js')
    ],
    cb
  );
});

gulp.task('minCss', function () {
  return gulp.src(['app/css/**/*.css' , '!css/**/*.min.css'])
		.pipe(cleanCSS({compatibility: 'ie8'}))
	  /*
		.pipe(rename({suffix: '.min'}))
		.pipe(gulp.dest('app/css/min'));
	  */
		.pipe(gulp.dest('app/minify/css'));
});

gulp.task('minHtml', function() {
  return gulp.src(['app/*.html' , '!*.min.html'])
		.pipe(htmlmin({collapseWhitespace: true}))
	  /*
	  	.pipe(rename({suffix: '.min'}))
	  	.pipe(gulp.dest('app/'));
	  */
		.pipe(gulp.dest('app/minify'));
});
